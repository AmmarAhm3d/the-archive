﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using WebGrease.Activities;

namespace webform
{
    public partial class LoginForm : Page
    {
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = "Username";
            string password = "Password";

            // Validate user credentials against database
            string connectionString = "Server=AMMAR-NARSUN\\SQLEXPRESS;Database=HRDBConnection;Trusted_Connection=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string sql = "SELECT COUNT(*) FROM Users WHERE Username=@username AND Password=@password";
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", password);

                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        // Login successful
                        Response.Redirect("Welcome.aspx");
                    }
                    else
                    {
                        // Invalid credentials
                        System.Diagnostics.Debug.WriteLine("Invalid credentials");
                    }
                }

                connection.Close();
            }
        }
    }
}
