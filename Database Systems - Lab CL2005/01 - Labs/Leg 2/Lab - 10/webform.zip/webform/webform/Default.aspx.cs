﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Common;

namespace webform
{
    public partial class _Default : Page
    {
        string connectionString = ConfigurationManager.ConnectionStrings["DB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void LoginButton_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            string sql = "SELECT * FROM [User] WHERE Username = @Username AND Password = @Password";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Username", UserTextBox.Text);
            cmd.Parameters.AddWithValue("@Password", PassTextBox.Text);
            conn.Open();
            if(cmd.ExecuteScalar() != null)
            {
                Session["Username"] = UserTextBox.Text;
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Login Successfull');</script>");
                Response.Redirect("Contact.aspx");

            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Login Failed');</script>");
                System.Diagnostics.Debug.WriteLine("Login failed");
            }
        }
    }

}

